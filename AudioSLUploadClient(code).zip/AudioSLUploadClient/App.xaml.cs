﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Windows;
using AudioSLUploadClient.Classes;
using System.Windows.Navigation;
using AudioSLUploadClient;
using System.Web;
using System.Collections.Specialized;
using System.Deployment.Application;
using System.Net;


namespace AudioSLUploadClient
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {

     
        protected override void OnStartup(StartupEventArgs e)
        {
            base.OnStartup(e);

            AppDomain.CurrentDomain.UnhandledException += CurrentDomain_UnhandledException;
            Application.Current.DispatcherUnhandledException += Current_DispatcherUnhandledException;
            Dispatcher.UnhandledException += Dispatcher_UnhandledException;

            System.Net.ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;

            //#endif
            //  this.StartupUri = new Uri("Login.xaml", UriKind.Relative);

            //
            //No longer needed 2-7-2023
            //Globals.IsSignedOn = false;

            //string key = Globals.LicenseKey;

            //int orgID = Globals.OrgID;

            //if(string.IsNullOrEmpty(key) || orgID == 0)
            //{
            //    Globals.IsLicensed = false;
            //}
            //else
            //{

            //    Globals.OrganizationID = orgID;

            //    AudioSL.PlaylistService.PlaylistClient client = new AudioSL.PlaylistService.PlaylistClient();

            //    string MAC = client.IsLicensed(orgID, key);

            //    if (!string.IsNullOrEmpty(MAC) && MAC.ToLower() != "none")
            //    {
            //        if (AudioSL.Globals.CheckMAC(MAC))
            //        {
            //            string[] roles = { "Tuner" };
            //            Globals.UserRoles = roles;
            //            Globals.IsLicensed = true;
                                            
            //        }
            //        else
            //        {
            //            Globals.IsLicensed = false;

            //        }
            //    }
            //    else
            //    {
            //        Globals.IsLicensed = false;
                   
            //    }
            //}

            //Globals.IsSignedOn = false;

            this.StartupUri = new Uri("Pages/home.xaml", UriKind.Relative);


        }

        private void Dispatcher_UnhandledException(object sender, System.Windows.Threading.DispatcherUnhandledExceptionEventArgs e)
        {
            Exception ex = e.Exception;
            AudioSL.Globals.LogError(ex);

        }

        private void Current_DispatcherUnhandledException(object sender, System.Windows.Threading.DispatcherUnhandledExceptionEventArgs e)
        {

            Exception ex = e.Exception;
            AudioSL.Globals.LogError(ex);
        }

        private void CurrentDomain_UnhandledException(object sender, UnhandledExceptionEventArgs e)
        {
            Exception ex = (Exception) e.ExceptionObject;
            AudioSL.Globals.LogError(ex);
        }

        protected override void OnExit(ExitEventArgs e)
        {
            base.OnExit(e);

           

        }

        //private void LoadParamters()
        //{
        //    if (AppDomain.CurrentDomain.SetupInformation
        //        .ActivationArguments.ActivationData != null
        //        && AppDomain.CurrentDomain.SetupInformation
        //        .ActivationArguments.ActivationData.Length > 0)
        //    {
        //        string fname = "No filename given";

        //        try
        //        {
        //            fname = AppDomain.CurrentDomain.SetupInformation
        //                .ActivationArguments.ActivationData[0];

        //            // It comes in as a URI; this helps to convert it to a path.
        //            Uri uri = new Uri(fname);
        //            fname = uri.LocalPath;
        //            AudioTunerWpf.Classes.ConfigManager.LoadConfig(fname);
        //            Globals.ConfigDownloaded = true;

        //            this.StartupUri = new Uri("Pages/Home.xaml", UriKind.Relative);

        //        }
        //        catch (Exception ex)
        //        {

        //            MessageBox.Show(ex.Message);
        //            // For some reason, this couldn't be read as a URI.
        //            // Do what you must...
        //        }
        //    }
        //    else
        //    {
        //        //NavigationService ns = NavigationService.GetNavigationService(this);
        //        //this.StartupUri = new Uri("Login.xaml", UriKind.Relative);

        //        this.StartupUri = new Uri("UserNotAuthorized.xaml", UriKind.Relative);



        //    }
        //}

        //private NameValueCollection GetQueryStringParameters()
        //{
        //    NameValueCollection nameValueTable = new NameValueCollection();

        //    if (ApplicationDeployment.IsNetworkDeployed)
        //    {
        //        string queryString = ApplicationDeployment.CurrentDeployment.ActivationUri.Query;
        //        nameValueTable = HttpUtility.ParseQueryString(queryString);
        //    }

        //    return (nameValueTable);
        //}
    }
}
