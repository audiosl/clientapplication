﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Windows;
using AudioSLUploadClient.Classes;
using System.Windows.Navigation;
using AudioSLUploadClient;
using System.Web;
using System.Collections.Specialized;
using System.Deployment.Application;
using System.Net;


namespace AudioSLUploadClient
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {

     
        protected override void OnStartup(StartupEventArgs e)
        {
            base.OnStartup(e);

            AppDomain.CurrentDomain.UnhandledException += CurrentDomain_UnhandledException;
            Application.Current.DispatcherUnhandledException += Current_DispatcherUnhandledException;
            Dispatcher.UnhandledException += Dispatcher_UnhandledException;

            System.Net.ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;

            this.StartupUri = new Uri("Pages/home.xaml", UriKind.Relative);


        }

        private void Dispatcher_UnhandledException(object sender, System.Windows.Threading.DispatcherUnhandledExceptionEventArgs e)
        {
            Exception ex = e.Exception;
            AudioSL.Globals.LogError(ex);

        }

        private void Current_DispatcherUnhandledException(object sender, System.Windows.Threading.DispatcherUnhandledExceptionEventArgs e)
        {

            Exception ex = e.Exception;
            AudioSL.Globals.LogError(ex);
        }

        private void CurrentDomain_UnhandledException(object sender, UnhandledExceptionEventArgs e)
        {
            Exception ex = (Exception) e.ExceptionObject;
            AudioSL.Globals.LogError(ex);
        }

        protected override void OnExit(ExitEventArgs e)
        {
            base.OnExit(e);

           if(Globals.IsSignedOn)
            {
                try
                {
                    AudioSL.PlaylistService.PlaylistClient client = new AudioSL.PlaylistService.PlaylistClient();
                    client.RemoveSessionForUser(Globals.OrganizationID, Globals.UserName, Globals.SessionKey);
                }
                catch { }
            }

        }

        
    }
}
