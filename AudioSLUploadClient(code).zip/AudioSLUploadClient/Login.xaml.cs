﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using AudioSLUploadClient.Classes;
using System.Threading;
using System.Security.Permissions;
using System.Security.Principal;
using System.Net.NetworkInformation;

namespace AudioSLUploadClient
{
    /// <summary>
    /// Interaction logic for Login.xaml
    /// </summary>
    public partial class Login : Page
    {
        public Login()
        {
            

            InitializeComponent();

            Dispatcher.BeginInvoke(new Action(() =>
            {

                this.ShowsNavigationUI = true;

            }));

            string uid = Globals.ReadValueFromXML("Login");

            if(!string.IsNullOrEmpty(uid))
            {
                txtUsername.Text = uid;
            }

            
        }

        private void btnSubmit_Click(object sender, RoutedEventArgs e)
        {

           
            try
            {

                Globals.PassWord = txtPassword.Password;
                Globals.UserName = txtUsername.Text;

                AudioSL.PlaylistService.PlaylistClient client = new AudioSL.PlaylistService.PlaylistClient();
                AudioSL.PlaylistService.UserInfoModel uiModel = client.AuthenticateUser(Globals.UserName, Globals.PassWord, Globals.ApplicationName);

                if (uiModel.IsAuthenticated)
                {

                    Globals.IsSignedOn = true;

                    Globals.UserRoles = uiModel.Roles; ;
                    Globals.OrganizationID = uiModel.OrganizationID;
                    Globals.IsLicensed = true;
                    Globals.SessionKey = uiModel.SessionKey;
                    Globals.RunAds = uiModel.RunAds;

                    Globals.WriteValueToXML("Login", Globals.UserName);

                    NavigateToHome();
                    
                }
                else
                {
                    
                    Globals.IsSignedOn = false;
                    AudioSL.Globals.LogMessage("Failed logon attempt " + System.DateTime.Now.ToString());

                    MessageBox.Show("Login attempt failed.  Please check your user name and password and try again.");

                    NavigateToHome();
                }
            }
            catch(Exception ex)
            {

                if (ex.Message.ToLower() == "toomany")
                {
                    MessageBox.Show("There have been too many failed login attempts.");
                    NavigateToHome();
                }
                else
                {
                    AudioSL.Globals.LogError(ex);
                    NavigateToError();
                }
            }

        }

        private void NavigateToError()
        {

            NavigationService ns = NavigationService.GetNavigationService(this);
            Pages.ErrorPage page = new Pages.ErrorPage();

            ns.Navigate(page);
        }

        private void NavigateToHome()
        {

            NavigationService ns = NavigationService.GetNavigationService(this);
            Pages.Home page = new Pages.Home();

            ns.Navigate(page);
        }

        private void NavigateToUserNotAuthorized()
        {
            NavigationService ns = NavigationService.GetNavigationService(this);
            UserNotAuthorized page = new UserNotAuthorized();

            ns.Navigate(page);
        }
    }
}
