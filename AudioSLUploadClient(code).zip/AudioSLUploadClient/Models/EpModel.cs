﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AudioSLUploadClient.Models
{
    public class EpModel
    {

        public string Name { get; set; }
        public string EndPoint { get; set; }
        public int EndPointID { get; set; }
        public DateTime TimeStamp { get; set; }
        public bool Selected { get; set; } = false;

        public override string ToString()
        {
            return Name + " - " + EndPoint;
        }
    }
}
