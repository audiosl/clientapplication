﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using AudioSLUploadClient.Classes;
using AudioSL.PlaylistService;

namespace AudioSLUploadClient.Pages
{
    /// <summary>
    /// Interaction logic for Position.xaml
    /// </summary>
    public partial class Position : Page
    {

        List<AudioModel> announcementList;
        private PlaylistClient client;

        public Position(List<AudioModel> model)
        {
            InitializeComponent();

            try
            {
                Dispatcher.BeginInvoke(new Action(() =>
                {
                    this.ShowsNavigationUI = true;

                }));

            }
            catch (Exception ex)
            {
                AudioSL.Globals.LogError(ex);
                MessageBox.Show("An error has been generated.  We apologize for the inconvenience");
            }

            this.announcementList = model;
            string titles = String.Empty;

            foreach(var item in announcementList)
            {
                titles += item.Title + Environment.NewLine;
            }

            txtTitle.Text = titles;

            client = new AudioSL.PlaylistService.PlaylistClient();

            AudioSL.PlaylistService.SelectListModel[] playLists = client.ListPlaylistForOrganization(Globals.OrganizationID, 0, Globals.SessionKey);

            if (playLists == null || playLists.Count() == 0)
            {
                MessageBox.Show("There are no play lists being returned for your organization.  You must first create a play list to add the new audio item.");
                return;
            }

            listPlaylists.ItemsSource = playLists;

        }

        private void btnSubmit_Click(object sender, RoutedEventArgs e)
        {

            try
            {
                if (announcementList.Count == 0)
                {
                    MessageBox.Show("There are no announements selected. Return to the previous page and select one or more announcements");
                    return;
                }

                var items = listPlaylists.Items;
                List<int> playlistIDs = new List<int>();

                foreach (var item in items)
                {

                    if (((SelectListModel)item).Selected)
                    {
                        int id = ((SelectListModel)item).ID;
                        playlistIDs.Add(id);
                    }
                }

                if (playlistIDs.Count == 0)
                {
                    MessageBox.Show("There are no playlist selected.");
                    return;
                }

                if (String.IsNullOrEmpty(txtInterval.Text))
                {
                    MessageBox.Show("There is no value for 'Interval'.");
                    return;

                }
                int interval = int.Parse(txtInterval.Text);

                bool remove = chkRemove.IsChecked == null ? false : (bool)chkRemove.IsChecked;

                List<PlaylistPositionModel> newAnnouncements = new List<PlaylistPositionModel>();

                foreach (int playListID in playlistIDs)
                {

                    PlaylistPositionModel[] pos = client.GetPlayListPositions(playListID, Globals.SessionKey);

                    List<PlaylistPositionModel> pliList = new List<PlaylistPositionModel>(pos);

                    List<PlaylistPositionModel> pliDirtyList = new List<PlaylistPositionModel>();

                    pliList = pliList.OrderBy(m => m.Position).ToList();

                    if (remove)
                    {
                        pliList = RemoveAnnouncementsFromList(pliList, ref pliDirtyList);
                    }

                    List<PlaylistPositionModel> pliNewList = new List<PlaylistPositionModel>();

                    while (pliList.Count > 0)
                    {
                        List<PlaylistPositionModel> pliTempList = pliList.Take(interval).ToList();

                        pliNewList.AddRange(pliTempList);

                        foreach (var am in announcementList)
                        {
                            PlaylistPositionModel model = new PlaylistPositionModel { AudioID = am.AudioID, AudioType = -1, Position = -1, Remove = false };
                            pliNewList.Add(model);
                        }

                        if (pliList.Count > interval)
                        {
                            pliList.RemoveRange(0, interval);
                        }
                        else if (pliList.Count > 0)
                        {
                            pliList.Clear();
                        }

                    }

                    int n = 1;
                    foreach (var pli in pliNewList)
                    {
                        if (pli.Remove)
                        {
                            continue;
                        }
                        else
                        {
                            pli.Position = n++;

                        }
                    }

                    //put objects t be removed at end of list
                    if (pliDirtyList.Count > 0)
                    {
                        pliNewList.AddRange(pliDirtyList);
                    }

                    client.SetPlayListPositions(playListID, pliNewList.ToArray(), Globals.UserName, Globals.SessionKey);

                }

                MessageBox.Show("The announcement insertion was successful.");

            }
            catch(Exception ex)
            {
                AudioSL.Globals.LogError(ex);
                MessageBox.Show("There was a problem in inserting announcements.");
            }

        }

        private List<PlaylistPositionModel> RemoveAnnouncementsFromList(List<PlaylistPositionModel> dirtyList,ref List<PlaylistPositionModel> removedList)
        {

            List<PlaylistPositionModel> cleanList = new List<PlaylistPositionModel>();

            foreach (var p in dirtyList)
            {
                if(p.AudioType != 1)
                {
                    removedList.Add(p);
                    p.Remove = true;
                  
                }
                else
                {
                    cleanList.Add(p);
                }
            }

            return cleanList.OrderBy(m=>m.Position).ToList();
        }
    }
}
