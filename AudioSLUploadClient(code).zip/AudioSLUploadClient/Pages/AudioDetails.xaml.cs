﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using AudioSLUploadClient.Classes;

namespace AudioSLUploadClient.Pages
{
    /// <summary>
    /// Interaction logic for Songs.xaml
    /// </summary>
    [RolesAuthorization("AllowUploadAnnouncement, UserAdmin")]
    public partial class AudioDetails : ApplicationPage
    {
        private int PlayListID { get; set; }

        public AudioDetails(int playListID)
        {

            this.PlayListID = playListID;

            Dispatcher.BeginInvoke(new Action(() =>
            {
                this.ShowsNavigationUI = true;


            }));

            LoadAudio();


        }

        private void LoadAudio()
        {
            AudioSL.PlaylistService.PlaylistClient client = new AudioSL.PlaylistService.PlaylistClient();
            AudioSL.PlaylistService.PlaylistItemModel[] audioModels = client.GetPlayListItems2(PlayListID, Globals.SessionKey);

            
            dataGridAudio.Items.Clear();

            List<AudioSL.PlaylistService.PlaylistItemModel> audioList = audioModels.ToList();

            dataGridAudio.ItemsSource = audioList;
            dataGridAudio.CanUserAddRows = false;
            dataGridAudio.AutoGenerateColumns = false;

        }

        public override void InitializeComponentB()
        {
            InitializeComponent();
        }

        protected override void NavigateToUserNotAuthorized()
        {

            NavigationService ns = NavigationService.GetNavigationService(this);

            if (ns != null)
            {
                UserNotAuthorized page = new UserNotAuthorized();
                ns.Navigate(page);
            }

        }

        
    }
}
