﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using AudioSLUploadClient.Classes;

namespace AudioSLUploadClient.Pages
{
    /// <summary>
    /// Interaction logic for Songs.xaml
    /// </summary>
    [RolesAuthorization("AllowUploadAnnouncement, UserAdmin")]
    public partial class Audio : ApplicationPage
    {


        public Audio()
        {



            Dispatcher.BeginInvoke(new Action(() =>
            {
                this.ShowsNavigationUI = true;


            }));

            LoadAudio();


        }

        private void LoadAudio()
        {
            AudioSL.PlaylistService.PlaylistClient client = new AudioSL.PlaylistService.PlaylistClient();

            AudioSL.PlaylistService.PlayListModel[] playLists = client.GetPlaylistsForOrg(Globals.OrganizationID, Globals.SessionKey);

            if (playLists == null || playLists.Count() == 0)
            {
                MessageBox.Show("There are no play lists being returned for your organization.  You must first create a play list to add the new audio item.");
                return;
            }

            dataGridAudio.Items.Clear();

            List<AudioSL.PlaylistService.PlayListModel> plList = playLists.ToList();

            dataGridAudio.ItemsSource = plList;
            dataGridAudio.CanUserAddRows = false;
            dataGridAudio.AutoGenerateColumns = false;

        }

        public override void InitializeComponentB()
        {
            InitializeComponent();
        }

        protected override void NavigateToUserNotAuthorized()
        {

            NavigationService ns = NavigationService.GetNavigationService(this);

            if (ns != null)
            {
                UserNotAuthorized page = new UserNotAuthorized();
                ns.Navigate(page);
            }

        }

        private void ViewDetailsHandler(object sender, RoutedEventArgs e)
        {

            AudioSL.PlaylistService.PlayListModel model = (AudioSL.PlaylistService.PlayListModel)((Button)e.Source).DataContext;

            int playListID = model.PlaylistID;

            NavigationService ns = NavigationService.GetNavigationService(this);
            AudioDetails page = new AudioDetails(playListID);

            ns.Navigate(page);

        }
    }
}
