﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using AudioSLUploadClient.Classes;
using Microsoft.Win32;
using AudioSLUploadClient.Models;
using AudioSL.PlaylistService;

namespace AudioSLUploadClient.Pages
{
    /// <summary>
    /// Interaction logic for CreateAnnouncement.xaml
    /// </summary>
    /// 
    [RolesAuthorization("AllowUploadAnnouncement, UserAdmin")]
    public partial class CreateAnnouncement : ApplicationPage
    {

        private AudioSL.PlaylistService.PlaylistClient client;
        private string EndPoint { get; set; }
        
        public CreateAnnouncement():base()
        {

            try
            {
                Dispatcher.BeginInvoke(new Action(() =>
                {
                    this.ShowsNavigationUI = true;


                }));

                client = new AudioSL.PlaylistService.PlaylistClient();

                AudioSL.PlaylistService.SelectListModel[] playLists = client.ListPlaylistForOrganization(Globals.OrganizationID, 0, Globals.SessionKey);

                if (playLists == null || playLists.Count() == 0)
                {
                    MessageBox.Show("There are no play lists being returned for your organization.  You must first create a play list to add the new audio item.");
                    return;
                }

                listPlaylists.ItemsSource = playLists;

                List<AudioSLUploadClient.Models.SelectionModel> listEndPoints = new List<Models.SelectionModel>();

                if (Globals.ShowDefaultEndpoint)
                {
                    string defaultEndpoint = client.GetDefaultEndpoint(Globals.SessionKey);

                    if (!String.IsNullOrEmpty(defaultEndpoint))
                    {
                        SelectionModel epDefaultModel = new SelectionModel
                        {
                           
                            Text = "Default",
                            Value = defaultEndpoint,
                            Selected = false
                            
                        };

                        listEndPoints.Add(epDefaultModel);
                    }
                }

                EndPointModel[] epModels = client.GetEndPoints(Globals.OrganizationID, Globals.SessionKey);

                foreach(var epModel in epModels)
                {
                    SelectionModel selectedModel = new SelectionModel
                    {
                        Selected = false,
                        Text = epModel.Name + " - " + epModel.EndPoint,
                        Value = epModel.EndPoint

                    };

                    listEndPoints.Add(selectedModel);
                }

                SelectionModel selected = listEndPoints.FirstOrDefault();

                if (selected != null)
                {
                    selected.Selected = true;
                }

                listEndpoints.ItemsSource = listEndPoints;

                fileTransfer1.FileUploadCompleted += new FileUploadCompletedDelegate(fileTransfer1_FileUploadCompleted);
                fileTransfer1.FileUploadCancelled += new FileUploadCancelledDelegate(fileTransfer1_FileUploadCancelled);

            }
            catch(Exception ex)
            {
                AudioSL.Globals.LogError(ex);
                MessageBox.Show("An error has occured.  We apologize for the inconveniance");

            }
        }

        protected override void NavigateToUserNotAuthorized()
        {
  
            NavigationService ns = NavigationService.GetNavigationService(this);

            if (ns != null)
            {
                UserNotAuthorized page = new UserNotAuthorized();
                ns.Navigate(page);
            }

        }

        public override void InitializeComponentB()
        {
            InitializeComponent();
        }

        void fileTransfer1_FileUploadCancelled()
        {
            btnSubmit.IsEnabled = true;
            NavigationService ns = NavigationService.GetNavigationService(this);
            ns.GoBack();
        }

        void fileTransfer1_FileUploadCompleted(object sender, FileUploadCompletedEventArgs args)
        {

            btnSubmit.IsEnabled = true;

            List<int> ids = new List<int>();

            var items = listPlaylists.Items;
                        
            foreach (var item in items)
            {

                if (((AudioSL.PlaylistService.SelectListModel)item).Selected)
                {
                    int id = ((AudioSL.PlaylistService.SelectListModel)item).ID;
                    ids.Add(id);
                }
            }

            //if (ids.Count == 0)
            //{
            //    MessageBox.Show("There is no play list selected.");
            //    return;
            //}

            string fileName = System.IO.Path.GetFileNameWithoutExtension(args.FileName) + ".x79";

            if (chkBoost.IsChecked == null ? false : (bool) chkBoost.IsChecked)
            {
                client.SetAnnouncementProperties(Globals.OrganizationID, txtTitle.Text,
                    Globals.UserName, fileName, ids.ToArray(), EndPoint, Globals.SessionKey, true);
            }
            else
            {
                client.SetAnnouncementProperties(Globals.OrganizationID, txtTitle.Text,
                    Globals.UserName, fileName, ids.ToArray(), EndPoint, Globals.SessionKey, false);
            }

            

            NavigationService ns = NavigationService.GetNavigationService(this);
            Announcements page = new Announcements();

            ns.Navigate(page);
        }

        
        private void btnSubmit_Click(object sender, RoutedEventArgs e)
        {

            try
            {

                if(String.IsNullOrEmpty(txtTitle.Text))
                {
                    MessageBox.Show("A value for title must be entered.");
                    return;
                }

                var endPointItems = listEndpoints.Items;
                EndPoint = String.Empty;

                foreach(var epItem in endPointItems)
                {
                    if (((AudioSLUploadClient.Models.SelectionModel)epItem).Selected)
                    {
                        EndPoint = ((AudioSLUploadClient.Models.SelectionModel)epItem).Value;
                        break;
                        
                    }
                }

                if(EndPoint == null || EndPoint == String.Empty)
                {
                    MessageBox.Show("There is no end point selected.");
                    return;
                }

                //see if this upload is going to default endpoint
                string defaultEndpoint = client.GetDefaultEndpoint(Globals.SessionKey);

                if (defaultEndpoint.ToLower() == EndPoint.ToLower())
                {

                    int remaining = client.GetNumberUploadsRemaining(Globals.OrganizationID, Globals.SessionKey);

                    if (remaining <= 0)
                    {
                        MessageBox.Show("There are no available uploads to default server. Remove one of the previous uploads.");
                        return;
                    }
                }

                btnSubmit.IsEnabled = false;

                string endPointUrl = EndPoint;

                if (!endPointUrl.EndsWith("/"))
                {
                    endPointUrl += "/";
                }

                endPointUrl += "uploadaudio";

                fileTransfer1.UploadUrl = new Uri(endPointUrl);

                fileTransfer1.Upload();
      
  
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);

            }

        }

    }
}
