﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using AudioSLUploadClient.Classes;
using System.Data;
using System.Collections.ObjectModel;

namespace AudioSLUploadClient.Pages
{
    /// <summary>
    /// Interaction logic for Announcements.xaml
    /// </summary>
    [RolesAuthorization("AllowUploadAnnouncement, UserAdmin")]
    public partial class Announcements : ApplicationPage
    {

        private List<AudioSL.PlaylistService.AudioModel> audioList;
        private List<AudioSL.PlaylistService.AudioModel> audioSelectedList;

        public Announcements()
        {

            try
            {
                Dispatcher.BeginInvoke(new Action(() =>
                {
                    this.ShowsNavigationUI = true;


                }));

                LoadAudio();
            }
            catch(Exception ex)
            {
                AudioSL.Globals.LogError(ex);
                MessageBox.Show("An error has been generated.  We apologize for the inconvenience");
            }

            
        }

        private void LoadAudio()
        {
            AudioSL.PlaylistService.PlaylistClient client = new AudioSL.PlaylistService.PlaylistClient();

            AudioSL.PlaylistService.AudioModel[] audioModels = client.GetAudioForOrganization(Globals.OrganizationID, Globals.SessionKey);
                   
            dataGridSongs.Items.Clear();

            audioList = audioModels.ToList();
            
            dataGridSongs.ItemsSource = audioList;
            dataGridSongs.CanUserAddRows = false;
            dataGridSongs.AutoGenerateColumns = false;

            audioSelectedList = new List<AudioSL.PlaylistService.AudioModel>();

        }

        public override void InitializeComponentB()
        {
            InitializeComponent();
        }

        protected override void NavigateToUserNotAuthorized()
        {

            NavigationService ns = NavigationService.GetNavigationService(this);

            if (ns != null)
            {
                UserNotAuthorized page = new UserNotAuthorized();
                ns.Navigate(page);
            }

        }

        private void btnCreateAnnouncement_Click(object sender, RoutedEventArgs e)
        {

            NavigationService ns = NavigationService.GetNavigationService(this);

            CreateAnnouncement page = new CreateAnnouncement();

            ns.Navigate(page);
        }

        //private void PositionAnnouncement(object sender, RoutedEventArgs e)
        //{

        //    AudioSL.PlaylistService.AudioModel model = (AudioSL.PlaylistService.AudioModel)((Button)e.Source).DataContext;

        //    NavigationService ns = NavigationService.GetNavigationService(this);
        //    Position page = new Position(model);

        //    ns.Navigate(page);
            
        //}

        private void DeleteFile(object sender, RoutedEventArgs e)
        {

            AudioSL.PlaylistService.AudioModel model = (AudioSL.PlaylistService.AudioModel)((Button)e.Source).DataContext;

            string fileName = model.Filename;
            string title = model.Title;
            string endPoint = model.EndPoint;
            int audioID = model.AudioID;

            MessageBoxResult result = MessageBox.Show("Are you sure you want to delete " + title + "?", "Delete File", MessageBoxButton.YesNo, MessageBoxImage.Question);
            if (result == MessageBoxResult.Yes)
            {

                try
                {
                    DeleteManager dMgr = new DeleteManager();
                    dMgr.DeleteFileOnServer(fileName, endPoint);

                    string audioRepository = Globals.AudioRepositoryFolder;

                    dMgr.DeleteLocalFile(audioRepository, fileName);

                    AudioSL.PlaylistService.PlaylistClient client = new AudioSL.PlaylistService.PlaylistClient();

                    client.DeleteAudio(audioID, Globals.OrganizationID, Globals.SessionKey);

                    audioList.Remove(model);

                    //dataGridSongs.Items.Clear();
                    dataGridSongs.ItemsSource = null;
                    dataGridSongs.ItemsSource = audioList;
                }
                catch(Exception ex)
                {
                    AudioSL.Globals.LogError(ex);
                }

            }

            
        }

        private void onCheckClick(object sender, RoutedEventArgs e)
        {

            System.Windows.Controls.CheckBox ctrl = (System.Windows.Controls.CheckBox) sender;

            AudioSL.PlaylistService.AudioModel model = (AudioSL.PlaylistService.AudioModel) ctrl.DataContext;

            if(ctrl.IsChecked != null && (bool)ctrl.IsChecked)
            {
                audioSelectedList.Add(model);
            }
            else
            {
                audioSelectedList.Remove(model);
            }

        }

        private void btnInsert_Click(object sender, RoutedEventArgs e)
        {
            if(audioSelectedList.Count == 0)
            {
                MessageBox.Show("There are no announements selected. Select one or more announcements.");
                return;
            }

            NavigationService ns = NavigationService.GetNavigationService(this);
            Position page = new Position(audioSelectedList);

            ns.Navigate(page);
        }

        
    }
}
