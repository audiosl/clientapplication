﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using AudioSLUploadClient.Classes;
using AudioSL.PlaylistService;
using AudioSLUploadClient.Models;

namespace AudioSLUploadClient.Pages
{
    /// <summary>
    /// Interaction logic for EndPoints.xaml
    /// </summary>
    [RolesAuthorization("UserAdmin, Developer")]
    public partial class EndPoints : ApplicationPage
    {

        private AudioSL.PlaylistService.PlaylistClient client = null;

        public EndPoints()
        {


            Dispatcher.BeginInvoke(new Action(() =>
            {
                this.ShowsNavigationUI = true;


            }));

            client = new AudioSL.PlaylistService.PlaylistClient();

            InitializeEPList();
            
        }

        private void InitializeEPList()
        {

            lstEndPoints.ItemsSource = null;

            List<EpModel> lstModels = new List<EpModel>();

            if (Globals.ShowDefaultEndpoint)
            {

                string defaultEndpoint = client.GetDefaultEndpoint(Globals.SessionKey);

                if (!String.IsNullOrEmpty(defaultEndpoint))
                {
                    EpModel defaultModel = new EpModel
                    {
                        EndPoint = defaultEndpoint,
                        Name = "Default",
                        TimeStamp = DateTime.Now,
                        EndPointID = -1
                    };

                    lstModels.Add(defaultModel);
                }

            }

            EndPointModel[] endPoints = client.GetEndPoints(Globals.OrganizationID, Globals.SessionKey);

            foreach(var ep in endPoints)
            {
                EpModel epModel = new EpModel
                {
                    EndPoint = ep.EndPoint,
                    EndPointID = ep.EndPointID,
                    Name = ep.Name,
                    TimeStamp = ep.TimeStamp

                };

                lstModels.Add(epModel);
            }

           

            lstEndPoints.ItemsSource = lstModels;

        }

        void DeleteHandler(object sender, RoutedEventArgs e)
        {
            
            if(lstEndPoints.SelectedItem == null)
            {
                MessageBox.Show("An item from the list must be selected.");
                return;
            }
            EpModel selected = (EpModel) lstEndPoints.SelectedItem;

            if(selected == null)
            {
                return;
            }


            if(selected.Name.Trim().ToLower() == "default")
            {

                Globals.WriteValueToXML("ShowDefaultEndpoint", "No");
                InitializeEPList();
                return;
            }


            client.DeleteEndPoint(selected.EndPointID, Globals.SessionKey);
            InitializeEPList();
            

        }

        void AddHandler(object sender, RoutedEventArgs e)
        {

            string name = txtEpName.Text;
            string ep = txtEndPoint.Text;

            if(String.IsNullOrEmpty(name) || String.IsNullOrEmpty(ep))
            {
                MessageBox.Show("A value for End Point Name and End Point must be entered.");
                return;
            }

            client.CreateEndPoint(Globals.OrganizationID, Globals.SessionKey, name, ep);
            InitializeEPList();

            txtEpName.Text = String.Empty;
            txtEndPoint.Text = String.Empty;

        }

        public override void InitializeComponentB()
        {
            InitializeComponent();
        }

        protected override void NavigateToUserNotAuthorized()
        {
            NavigationService ns = NavigationService.GetNavigationService(this);

            if (ns != null)
            {
                UserNotAuthorized page = new UserNotAuthorized();
                ns.Navigate(page);
            }
        }
    }
}
