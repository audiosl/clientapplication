﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using AudioSLUploadClient.Classes;
using AudioSLUploadClient.Pages;


namespace AudioSLUploadClient.Pages
{
    /// <summary>
    /// Interaction logic for Home.xaml
    /// </summary>
    
    
    public partial class Home : ApplicationPage
    {

      //  PlaylistService.PlaylistClient client = new PlaylistService.PlaylistClient();

        public Home()
        {
            

            Dispatcher.BeginInvoke(new Action(() =>
            {
                this.ShowsNavigationUI = false;

                //if (!Globals.ValidateAuthorization(this.GetType()))
                //{
                //    NavigateToUserNotAuthorized();
                //}

                 
            }));

            //int[] counts = client.GetAudioCountForOrganization(Globals.OrganizationID);

            //Globals.SongCount = counts[2];
            //Globals.AnnouncementCount = counts[3];
            //Globals.SongsUploaded = counts[0];
            //Globals.AnnouncementsUploaded = counts[1];

            //int orgID = int.Parse(System.Configuration.ConfigurationManager.AppSettings["OrgID"]);
            //Globals.OrganizationID = orgID;

        }

        public override void InitializeComponentB()
        {
            InitializeComponent();
        }

        protected override void NavigateToUserNotAuthorized()
        {

            NavigationService ns = NavigationService.GetNavigationService(this);

            if (ns != null)
            {
                UserNotAuthorized page = new UserNotAuthorized();
                ns.Navigate(page);
            }

        }



    }
}
