﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
//using System.Xml;
using System.Xml.Linq;

namespace AudioSLUploadClient.Classes
{
    public class ConfigManager
    {

        public static void LoadConfig(string fname)
        {

            try
            {
                string xmlString = String.Empty;
                XElement root = XElement.Load(fname);

                var org =
                    (from el in root.Elements("ID")
                     // where (string)el.Element("CommandLine") == "Examp2.EXE"
                     select el).FirstOrDefault();

                Globals.OrganizationID = int.Parse(org.Value);

                IEnumerable<XElement> roles = from el in root.Elements("Roles") select el;

                var rolesEnum = from el in roles.Elements("Role") select el;

                List<string> rolesList = new List<string>();

                foreach (var role in rolesEnum)
                {
                    rolesList.Add(role.Value);
                }

                Globals.UserRoles = rolesList.ToArray();

                var un = (from el in root.Elements("UserName")
                                    select el).FirstOrDefault();

                Globals.UserName = un.Value.ToString();

            }
            catch 
            {
                throw;
            }

           

        }

    }
}
