﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Reflection;
using System.IO;
using System.Windows;
using System.Diagnostics;
using System.Xml.Linq;
using System.Net.NetworkInformation;

namespace AudioSLUploadClient.Classes
{

    public class Globals
    {

        public const string ApplicationName = "USD.MvcPlaylistApp";

        private static string _userName = String.Empty;
        public static string UserName 
        {
            get
            {
                return _userName;
            }
            set
            {
                _userName = value;
            }
        }

        private static string _password = String.Empty;
        public static string PassWord 
        {
            get
            {
                
                return _password;
            }
            set
            {
                _password = value;
            }
        }

        private static Boolean _runAds = false;

        public static Boolean RunAds
        {
            get
            {
                return _runAds;
            }
            set
            {
                _runAds = value;
            }
        }

        public static bool ConfigDownloaded { get; set; }
        
        public static bool ValidateAuthorization(Type type)
        {
            object[] attributes = type.GetCustomAttributes(true);

            object attr = null;

            foreach (object o in attributes)
            {
                Type t = o.GetType();

                if (t.Name == "RolesAuthorization")
                {
                    attr = o;
                    break;
                }
            }

            if (attr == null)
            {
                
                return true;
            }

            bool isAuthenticated = ((RolesAuthorization)attr).IsAuthenticated;

            return isAuthenticated;

        }

        public static bool IsUserInRole(string authRole)
        {
            if (UserRoles == null)
            {
                return false;
            }

            foreach (string userRole in UserRoles)
            {
                string lowerUserRole = userRole.ToLower().Trim();

                if (lowerUserRole == authRole.ToLower().Trim())
                {
                    return true;
                }
               
            }

            return false;

        }

        public static bool IsUserInRoles(string[] authorizationRoles)
        {
            if (UserRoles == null)
            {
                return false;
            }

            foreach (string userRole in UserRoles)
            {

                string lowerUserRole = userRole.ToLower().Trim();

                foreach (string authRole in authorizationRoles)
                {
                    string lowerAuthRole = authRole.ToLower().Trim();

                    if (lowerAuthRole == lowerUserRole)
                    {
                        return true;
                    }
                }
            }

            return false;
        }

        //public static string ApplicationName
        //{
        //    get
        //    {
        //        return System.Configuration.ConfigurationManager.AppSettings["ApplicationName"];
        //    }
        //}

        public static string EndPoints
        {

            get
            {
                return ReadValueFromXML("Endpoints");
            }
        }

        public static int OrgID
        {
            get
            {
                string orgid = ReadValueFromXML("OrgID");

                if(string.IsNullOrEmpty(orgid))
                {
                    return 0;
                }
                else
                {
                    return int.Parse(orgid);
                }
            }
        }

        public static string[] UserRoles {get; set;}

        public static int SongCount { get; set; }
        public static int AnnouncementCount { get; set; }

        public static int SongsUploaded { get; set; }
        public static int AnnouncementsUploaded { get; set; }
        public static string MAC { get; set; }

        public static bool IsLicensed { get; set; }

        static bool _isSignedOn = false;
        public static bool IsSignedOn
        {
            get
            {
                return _isSignedOn;
            }
            set
            {
                _isSignedOn = value;
            }
        }

        private static string _licenseKey = string.Empty;
        public static string SessionKey 
        { 
            get
            {
                return _licenseKey;
            }
            set
            {
                _licenseKey = value;
            }
        }
    
        private static int _orgid = -1;
        public static int OrganizationID 
        {
            get
            {
                return _orgid;
            }
            set
            {
                _orgid = value;
            }
        }

        //public static void WriteToConfiguration(string key, string value)
        //{
        //    System.Configuration.Configuration configuration =
        //      System.Configuration.ConfigurationManager.OpenExeConfiguration(System.Configuration.ConfigurationUserLevel.None);
        //    configuration.AppSettings.Settings[key].Value = value;
        //    configuration.Save(System.Configuration.ConfigurationSaveMode.Full, true);
        //    System.Configuration.ConfigurationManager.RefreshSection("appSettings");
        //}

        public static string BinariesFolder
        {
            get
            {

                string dir = GetExecutingFolder();
                return Path.Combine(dir, "binaries");

            }
        }

        public static string  GetExecutingFolder()
        {
            string appPath = System.Reflection.Assembly.GetExecutingAssembly().Location;
            return Path.GetDirectoryName(appPath);
        }

        public static string AudioRepositoryFolder
        {
            get
            {

                string dir = GetExecutingFolder();
                return Path.Combine(dir, "AudioRepository");

            }
        }

        public static string ReadValueFromXML(string value)
        {

            //   string path = GetTopFolder();

            string path = Environment.CurrentDirectory;

           // path = Path.GetDirectoryName(path);

            string file = Path.Combine(path, "X53.xml");

            try 
            {
                XElement xmlDoc = XElement.Load(file);

                //var settings = (from item in xmlDoc.Descendants("appSetting")
                //                                      select item);

                var setting = (from item in xmlDoc.Descendants("appSetting")
                                where (string)item.Attribute("key") == value
                                select item).FirstOrDefault();

                if (setting != null)
                {
                    string retVal = setting.Attribute("value").Value.ToString();
                    return retVal;
                }
                else
                {
                    return String.Empty;
                }
                
            }
            catch (Exception ex)
            {
                AudioSL.Globals.LogError(ex);
                return String.Empty;
            }
        }

        public static void WriteValueToXML(string key, string value)
        {

            try
            {
                string path = System.Reflection.Assembly.GetExecutingAssembly().Location;

                path = Path.GetDirectoryName(path);

                string file = Path.Combine(path, "X53.xml");

                XElement xmlDoc = XElement.Load(file);

                var setting = (from item in xmlDoc.Descendants("appSetting")
                               where (string)item.Attribute("key") == key
                               select item).FirstOrDefault();

                setting.SetAttributeValue("value", value);

                xmlDoc.Save(file);

                
            }
            catch
            {
                throw;
            }

        }

        public static bool ShowDefaultEndpoint
        {
            get
            {
                string showDefault = Globals.ReadValueFromXML("ShowDefaultEndpoint");

                if (!String.IsNullOrEmpty(showDefault) && (showDefault.ToLower() == "yes" ||
                    showDefault.ToLower() == "true"))
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
        }
    }
}
