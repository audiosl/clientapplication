﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net;
using System.IO;

namespace AudioSLUploadClient.Classes
{
    public class DeleteManager
    {
        public void DeleteFileOnServer(string file, string endPoint)
        {

            string sURL = endPoint;

            if(!sURL.EndsWith("/"))
            {
                sURL += "/";

            }

            sURL += "deleteaudio/" + file;

            WebRequest request = WebRequest.Create(sURL);
            request.Method = "DELETE";

            HttpWebResponse response = (HttpWebResponse)request.GetResponse();
        }

        public void DeleteLocalFile(string path, string fileName)
        {
            try
            {
                path = Path.Combine(path, fileName);

                FileInfo fi = new FileInfo(path);
                fi.Delete();

              //  File.Delete(path);
            }
            catch(Exception ex)
            {
                AudioSL.Globals.LogError(ex);
            }
        }
    }
}
