﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Controls;
using System.Windows.Navigation;

namespace AudioSLUploadClient.Classes
{
    public abstract class ApplicationPage : Page
    {
        //public IocContainer IocContainer { get; set; }
        public bool IsAuthenticated { get; set; }

        public abstract void InitializeComponentB();
        protected abstract void NavigateToUserNotAuthorized();

        public ApplicationPage()
        {
            InitializeComponentB();

            if (!Globals.ValidateAuthorization(this.GetType()))
            {
                NavigateToUserNotAuthorized();
            }
        }

        

        //public ApplicationPage(IocContainer container)
        //{
        //    InitializeComponentB();

        //    this.IocContainer = container;

        //    if (!Globals.ValidateAuthorization(this.GetType()))
        //    {
        //        NavigateToUserNotAuthorized();
        //    }
        //}

        


        
    }
}
