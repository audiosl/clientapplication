﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AudioSLUploadClient.Classes
{
    public class SongModel
    {
        public string Artist { get; set; }
        public string Title { get; set; }
        
    }
}
