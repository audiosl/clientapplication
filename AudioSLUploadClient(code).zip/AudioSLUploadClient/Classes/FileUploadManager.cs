﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.ComponentModel;
using System.IO;
using System.Windows.Threading;
using System.Text;
using System.Diagnostics;

namespace AudioSLUploadClient.Classes
{

    public delegate void FileUploadCompletedDelegate(object sender, FileUploadCompletedEventArgs args);
    public delegate void ProgressChangedEvent(object sender, UploadProgressChangedEventArgs args);
    public delegate void FileUploadCancelledDelegate();
    
    public class FileUploadCompletedEventArgs
    {
        public string FileName { get; set; }
   
        public FileUploadCompletedEventArgs() { }

        public FileUploadCompletedEventArgs(string fileName)
        {
            FileName = fileName;
       
        }
    }

    public class UploadProgressChangedEventArgs
    {
        public int ProgressPercentage { get; set; }
        public long BytesUploaded { get; set; }
        public long TotalBytesUploaded { get; set; }
        public long TotalBytes { get; set; }
        public string FileName { get; set; }
        

        public UploadProgressChangedEventArgs() { }

        public UploadProgressChangedEventArgs(int progressPercentage, long bytesUploaded, long totalBytesUploaded, long totalBytes, string fileName)
        {
            ProgressPercentage = progressPercentage;
            BytesUploaded = bytesUploaded;
            TotalBytes = totalBytes;
            FileName = fileName;
            TotalBytesUploaded = totalBytesUploaded;
        }
    }

    public enum FileUploadStatus
    {
        Pending,
        Uploading,
        Complete,
        Error,
        Canceled,
        Removed,
        Resizing
    }

    public class FileUploadManager : INotifyPropertyChanged
    {

        public event PropertyChangedEventHandler PropertyChanged;
        public event ProgressChangedEvent UploadProgressChanged;
        public event FileUploadCompletedDelegate FileUploadCompleted;
        public event FileUploadCancelledDelegate FileUploadCancelled;

        public string ContentType { get; set; }

       // public event EventHandler StatusChanged;

        private Dispatcher Dispatcher;
        private FileInfo file;
        public FileInfo File
        {
            get { return file; }
            set
            {
                file = value;
                Stream temp = file.OpenRead();
                FileLength = temp.Length;
                temp.Close();
            }
        }
        private Uri UploadUrl;
        public FileUploadStatus _status;

        public FileUploadStatus Status
        {
            get
            {
                return _status;
            }
            set
            {
                _status = value;
            }
        }

       
        public long ChunkSize = 0;

        private string _newFileName = String.Empty;
        public string NewFileName
        {
            get
            {
                return _newFileName.Trim();
            }
            set
            {
                _newFileName = value.Trim();
            }
        }

        private long fileLength;
        public long FileLength
        {
            get { return fileLength; }
            set
            {
                fileLength = value;

               
                if (PropertyChanged != null)
                        PropertyChanged(this, new PropertyChangedEventArgs("FileLength"));
               
            }
        }

        private long bytesUploaded;
        public long BytesUploaded
        {
            get { return bytesUploaded; }
            set
            {
                bytesUploaded = value;

                if (PropertyChanged != null)
                        PropertyChanged(this, new PropertyChangedEventArgs("BytesUploaded"));
               
            }
        }

        public FileUploadManager(Dispatcher dispatcher)
        {
            
            Status = FileUploadStatus.Pending;
            BytesUploaded = 0;
            Dispatcher = dispatcher;
        }

        public FileUploadManager(Dispatcher dispatcher, Uri uploadUrl, string newFileName)
            : this(dispatcher)
        {
            UploadUrl = uploadUrl;
            NewFileName = newFileName;
        }

        public FileUploadManager(Dispatcher dispatcher, Uri uploadUrl, FileInfo fileToUpload, string newFileName)
            : this(dispatcher, uploadUrl, newFileName)
        {
            File = fileToUpload;
        }

        public void UploadChunk()
        {

            try
            {
                if (File == null || UploadUrl == null)
                {
                    return;
                }

                long temp = FileLength - BytesUploaded;



                UriBuilder ub = new UriBuilder(UploadUrl);
                bool complete = temp <= ChunkSize;
                bool cancelled = false;

                string query = string.Format("filename={0}&StartByte={1}&Complete={2}&Cancelled={3}", NewFileName, BytesUploaded, complete, cancelled);

                ub.Query = query;

                HttpWebRequest webrequest = (HttpWebRequest)WebRequest.Create(ub.Uri);
                
                webrequest.Method = "PUT";

                webrequest.ContentType = ContentType;
                webrequest.ContentLength = FileLength;
                webrequest.KeepAlive = true;
                webrequest.Timeout = 400000;
                webrequest.SendChunked = true;
                webrequest.Accept = "audio/ogg";
                
                webrequest.BeginGetRequestStream(new AsyncCallback(GetRequestCallback), webrequest);
            }
            catch (Exception ex)
            {
                AudioSL.Globals.LogError(ex);
                throw;
            }

        }

        private void GetRequestCallback(IAsyncResult asynchronousResult)
        {

            try
            {
              

                HttpWebRequest webrequest = (HttpWebRequest)asynchronousResult.AsyncState;
                // End the operation.
                Stream requestStream = webrequest.EndGetRequestStream(asynchronousResult);

                byte[] buffer = new Byte[4096];
                int bytesRead = 0;
                int totalBytesPosted = 0;

                Stream fileStream = File.OpenRead();

                fileStream.Position = BytesUploaded;

                while ((bytesRead = fileStream.Read(buffer, 0, buffer.Length)) != 0 && totalBytesPosted + bytesRead < ChunkSize)
                {
                    requestStream.Write(buffer, 0, bytesRead);
                    requestStream.Flush();
                    BytesUploaded += bytesRead;
                    totalBytesPosted += bytesRead;

                    if (UploadProgressChanged != null)
                    {
                        int percent = (int)(((double)BytesUploaded / (double)FileLength) * 100);
                        UploadProgressChangedEventArgs args = new UploadProgressChangedEventArgs(percent, bytesRead, BytesUploaded, FileLength, file.Name);

                        Dispatcher.BeginInvoke(new Action(() =>
                        {
                            UploadProgressChanged(this, args);

                        }));



                    }
                }
                          
                fileStream.Close();
                requestStream.Close();

                webrequest.BeginGetResponse(new AsyncCallback(GetResponseCallback), webrequest);
            }
            catch (Exception ex)
            {
                AudioSL.Globals.LogError(ex);
                throw;
            }
        }

        private void GetResponseCallback(IAsyncResult asynchronousResult)
        {

            try
            {

                HttpWebRequest webrequest = (HttpWebRequest)asynchronousResult.AsyncState;
                HttpWebResponse response = (HttpWebResponse)webrequest.EndGetResponse(asynchronousResult);
                StreamReader reader = new StreamReader(response.GetResponseStream());

                string responsestring = reader.ReadToEnd();

                reader.Close();

                if (Status == FileUploadStatus.Canceled)
                {

                    CancelUpload();
                }
                else if (BytesUploaded < FileLength)
                {

                    UploadChunk();
                }
                else
                {

                    if (FileUploadCompleted != null)
                    {
                        FileUploadCompletedEventArgs args = new FileUploadCompletedEventArgs(NewFileName);

                        Dispatcher.BeginInvoke(new Action(() =>
                        {
                            FileUploadCompleted(this, args);

                        }));

                    }

                    Status = FileUploadStatus.Complete;

                    if(response != null)
                    {
                        response.Close();
                    }
                    
                }
            }
            catch (Exception ex)
            {

                AudioSL.Globals.LogError(ex);
                throw;

            }

        }

        private void CancelUpload()
        {

            if (FileUploadCancelled != null)
            {
                FileUploadCancelled();
            }

            //UriBuilder ub = new UriBuilder(UploadUrl);

            //string query = string.Format("Cancelled=true");
            //ub.Query = query;

            //HttpWebRequest request = (HttpWebRequest)WebRequest.Create(ub.Uri);

            //request.Method = "POST";

            //byte[] bytes = System.Text.Encoding.ASCII.GetBytes(form);

            //request.ContentType = "application/x-www-form-urlencoded";
            //request.ContentLength = bytes.Length;

            //Stream reqStream = ((HttpWebRequest)request).GetRequestStream();

            //reqStream.Write(bytes, 0, bytes.Length);

           
            //respStream.Close();
            //reqStream.Close();
        }
    }
}
