﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AudioSLUploadClient.Classes
{
    [AttributeUsage(AttributeTargets.All)]
    public class MyAttribute : Attribute
    {
        public MyAttribute()
        {
            string s = "test";
            string s1 = s;
        }
    }
}
