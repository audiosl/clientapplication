﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Security;

namespace AudioSLUploadClient.Classes
{
    [AttributeUsage(AttributeTargets.All)]
    public class RolesAuthorization : Attribute
    {
        public RolesAuthorization(string authorizedRoles)
        {
            string[] authorizedRolesArray = authorizedRoles.Split(',');
            IsAuthenticated = Globals.IsUserInRoles(authorizedRolesArray);
        }

        private bool isAuthenticated = false;
        public bool IsAuthenticated
        {
            get
            {
                return isAuthenticated;
            }
            set
            {
                isAuthenticated = value;
            }
        }
        
    }
}
