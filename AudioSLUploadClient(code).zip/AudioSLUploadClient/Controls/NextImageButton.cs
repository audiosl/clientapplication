﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.IO;
using System.Windows.Media.Imaging;


namespace AudioSLUploadClient.Controls
{
   
    [TemplatePart(Name = "PART_Image", Type = typeof(Image))]
    public class NextImageButton : Button
    {

        public Image PartImage;
        public MouseEnum mouse;

        public NextImageButton()
        {
            this.DefaultStyleKey = typeof(NextImageButton);
            mouse = MouseEnum.Unknown;
        }


       
        public override void OnApplyTemplate()
        {

            try
            {
                this.PartImage = this.GetTemplateChild("PART_Image") as Image;

                if (this.PartImage != null)
                {
                    Dispatcher.BeginInvoke(new Action(() =>
                    {
                        this.SetImageSource(Skip_Out);

                    }));
                }
            }
            catch { }
        }

        #region Dependency properties

        public byte[] Skip_Out
        {
            get
            {
                return (byte[])this.GetValue(SkipOutProperty);
            }
            set
            {
                this.SetValue(SkipOutProperty, value);
            }

        }

        public byte[] Skip_Over
        {
            get
            {
                return (byte[])this.GetValue(SkipOverProperty);
            }
            set
            {
                this.SetValue(SkipOverProperty, value);
            }

        }

        public static DependencyProperty SkipOutProperty = DependencyProperty.Register(
            "SkipOutProperty", typeof(byte[]), typeof(NextImageButton), new PropertyMetadata(null));

        public static DependencyProperty SkipOverProperty = DependencyProperty.Register(
            "SkipOverProperty", typeof(byte[]), typeof(NextImageButton), new PropertyMetadata(null));


        #endregion

        #region Button events

        protected override void OnMouseEnter(MouseEventArgs e)
        {

       
            base.OnMouseEnter(e);

            if (this.PartImage != null)
            {

                Dispatcher.BeginInvoke(new Action(() =>
                {
                    this.SetImageSource(Skip_Over);

                }));

            }
        }

        protected override void OnMouseLeave(MouseEventArgs e)
        {

            base.OnMouseLeave(e);

            if (this.PartImage != null)
            {
                Dispatcher.BeginInvoke(new Action(() =>
                {
                    this.SetImageSource(Skip_Out);

                }));

            }
        }

        #endregion

        /// <summary>
        /// Sets the image source.
        /// </summary>
        /// <param name="imageSource">The lang en image.</param>
        private void SetImageSource(byte[] imageSource)
        {
            try
            {
                using (var ms = new MemoryStream(imageSource, 0, imageSource.Length - 1))
                {
                    var bi = new BitmapImage();

                    bi.BeginInit();
                    bi.StreamSource = ms;
                    bi.CacheOption = BitmapCacheOption.OnLoad;
                    bi.EndInit();
                    
                    this.PartImage.Source = bi;
                }
            }
            catch { }
        }
    }
}
