﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using AudioSLUploadClient.Classes;
using AudioSLUploadClient.Pages;

namespace AudioSLUploadClient.Controls
{
    /// <summary>
    /// Interaction logic for Navigation.xaml
    /// </summary>
    public partial class Navigation : UserControl
    {
        public Navigation()
        {
            InitializeComponent();

           if(Globals.IsSignedOn)
            {
                SignOff.Visibility = Visibility.Visible;
                SignOn.Visibility = Visibility.Collapsed;
            }
           else
            {
                SignOff.Visibility = Visibility.Collapsed;
                SignOn.Visibility = Visibility.Visible;
            }

            if(Globals.IsUserInRole("AllowUploadAnnouncement") ||
                Globals.IsUserInRole("UserAdmin") ||
                Globals.IsUserInRole("Developer"))
            {
                AudioNav.Visibility = Visibility.Visible;
            }
            else
            {
                AudioNav.Visibility = Visibility.Collapsed;
            }

            if ((Globals.IsUserInRole("AllowUploadAnnouncement") ||
                Globals.IsUserInRole("UserAdmin")) &&
                Globals.RunAds)
            {
                ShowAnnouncements.Visibility = Visibility.Visible;
                ShowAll.Visibility = Visibility.Visible;
            }
            else
            {
                ShowAnnouncements.Visibility = Visibility.Collapsed;
                ShowAll.Visibility = Visibility.Collapsed;
            }

            if (Globals.IsUserInRole("UserAdmin") || Globals.IsUserInRole("Developer"))
            {
                EndPoints.Visibility = Visibility.Visible;

            }
            else
            {
                EndPoints.Visibility = Visibility.Collapsed;
            }

        }

      
        private void HomeHandler(object sender, RoutedEventArgs e)
        {
            NavigationService ns = NavigationService.GetNavigationService(this);
            AudioSLUploadClient.Pages.Home page = new Home();

            ns.Navigate(page);
        }


        private void AudioHandler(object sender, RoutedEventArgs e)
        {

            NavigationService ns = NavigationService.GetNavigationService(this);
            Audio page = new Audio();

            ns.Navigate(page);
        }

        private void AnnouncementsHandler(object sender, RoutedEventArgs e)
        {

            NavigationService ns = NavigationService.GetNavigationService(this);
            Announcements page = new Announcements();

            ns.Navigate(page);
        }

        private void CleanHandler(object sender, RoutedEventArgs e)
        {
            NavigationService ns = NavigationService.GetNavigationService(this);
            RemoveAllAnnouncements page = new RemoveAllAnnouncements();

            ns.Navigate(page);
        }

        private void LoginHandler(object sender, RoutedEventArgs e)
        {

            NavigationService ns = NavigationService.GetNavigationService(this);
            Login page = new Login();

            ns.Navigate(page);
        }

        private void LogoutHandler(object sender, RoutedEventArgs e)
        {

            try
            {
                AudioSL.PlaylistService.PlaylistClient client = new AudioSL.PlaylistService.PlaylistClient();
                client.RemoveSessionForUser(Globals.OrganizationID, Globals.UserName, Globals.SessionKey);
            }
            catch { }

            Globals.IsSignedOn = false;
            string[] roles = { "Tuner" };
            Globals.UserRoles = roles;
            Globals.SessionKey = String.Empty;
            Globals.OrganizationID = -1;

            NavigationService ns = NavigationService.GetNavigationService(this);
            Home page = new Home();

            ns.Navigate(page);
        }

        private void EndPointsHandler(object sender, RoutedEventArgs e)
        {

            NavigationService ns = NavigationService.GetNavigationService(this);
            EndPoints page = new EndPoints();

            ns.Navigate(page);
        }
    }
}
