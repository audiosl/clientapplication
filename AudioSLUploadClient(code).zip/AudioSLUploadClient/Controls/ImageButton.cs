﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.IO;
using System.Windows.Media.Imaging;
//using AudioTunerWpf.Abstract;
using AudioSLUploadClient.Classes;


namespace AudioSLUploadClient.Controls
{

    public enum MouseEnum
    {
        Over,
        Out, 
        Unknown
    }

    public enum AudioStateEnum
    {
        Start,
        Stop
    }

    public delegate void AudioStateChangedDelegate(AudioStateEnum audioState);

    [TemplatePart(Name = "PART_Image", Type = typeof(Image))]
    public class ImageButton : Button
    {

        public Image PartImage;
        public event AudioStateChangedDelegate AudioStateChanged;
       
        public MouseEnum mouse;
        private AudioStateEnum AudioState;

        public ImageButton()
        {
            this.DefaultStyleKey = typeof(ImageButton);
            mouse = AudioSLUploadClient.Controls.MouseEnum.Unknown;
            this.Click += ImageButton_Click;
            AudioState = AudioStateEnum.Stop;
        }

        private void ImageButton_Click(object sender, RoutedEventArgs e)
        {

            if (AudioState == AudioStateEnum.Stop)
            {
                AudioState = AudioStateEnum.Start;
                
            }
            else
            {
                AudioState = AudioStateEnum.Stop;
              
            }

            CurrentStateChanged();

            if (AudioStateChanged != null)
            {
                AudioStateChanged(AudioState);
            }
        }

        private void CurrentStateChanged()
        {

            switch (AudioState)
            {
                case AudioStateEnum.Start:
                

                    if (PartImage != null)
                    {
                        if (mouse == MouseEnum.Over)
                        {
                            
                            SetImageSource(Started_Over);

                        }
                        else
                        {
                            
                            SetImageSource(Started_Out);

                        }
                    }

                    break;

                case AudioStateEnum.Stop:
           
                    if (PartImage != null)
                    {

                        if (mouse == MouseEnum.Over)
                        {
                            
                                SetImageSource(Paused_Over);

                        }
                        else
                        {
                               
                                SetImageSource(Paused_Out);

                               
                        }
                    }
                    break;
            }
        }

        public override void OnApplyTemplate()
        {

            try
            {
                PartImage = this.GetTemplateChild("PART_Image") as Image;

                if (PartImage != null)
                {
                    //this.PartImage.MouseLeftButtonDown += this.PartImageOnMouseLeftButtonDown;
                    //this.PartImage.MouseLeftButtonUp += this.PartImageOnMouseLeftButtonUp;

                    
                        SetImageSource(Paused_Out);

                    
                }
            }
            catch { }
        }

        #region Dependency properties

        public byte[] Paused_Out
        {
            get
            {
                return (byte[])this.GetValue(PausedOutProperty);
            }
            set
            {
                this.SetValue(PausedOutProperty, value);
            }

        }

        public static DependencyProperty PausedOutProperty = DependencyProperty.Register(
            "PausedOutProperty", typeof(byte[]), typeof(ImageButton), new PropertyMetadata(null));


        public byte[] Paused_Over
        {
            get
            {
                return (byte[])this.GetValue(PausedOverProperty);
            }
            set
            {
                this.SetValue(PausedOverProperty, value);
            }

        }

        public static DependencyProperty PausedOverProperty = DependencyProperty.Register(
            "PausedOverProperty", typeof(byte[]), typeof(ImageButton), new PropertyMetadata(null));

        public byte[] Started_Over
        {
            get
            {
                return (byte[])this.GetValue(StartedOverProperty);
            }
            set
            {
                this.SetValue(StartedOverProperty, value);
            }

        }

        public static DependencyProperty StartedOverProperty = DependencyProperty.Register(
           "StartedOverProperty", typeof(byte[]), typeof(ImageButton), new PropertyMetadata(null));

        public byte[] Started_Out
        {
            get
            {
                return (byte[])this.GetValue(StartedOutProperty);
            }
            set
            {
                this.SetValue(StartedOutProperty, value);
            }

        }

        public static DependencyProperty StartedOutProperty = DependencyProperty.Register(
            "StartedOutProperty", typeof(byte[]), typeof(ImageButton), new PropertyMetadata(null));


        #endregion

        #region Button events

        protected override void OnMouseEnter(MouseEventArgs e)
        {

            mouse = MouseEnum.Over;

            base.OnMouseEnter(e);

            if (this.PartImage != null)
            {
               

                if (AudioState == AudioStateEnum.Start)
                {
                    
                        this.SetImageSource(Started_Over);

                    
                }
                else 
                {
                       
                        this.SetImageSource(Paused_Over);

                       
                }

                
            }
        }
    

        protected override void OnMouseLeave(MouseEventArgs e)
        {

            mouse = MouseEnum.Out;
            base.OnMouseLeave(e);

            if (this.PartImage != null)
            {
                if (AudioState == AudioStateEnum.Start)
                {
                   
                        this.SetImageSource(Started_Out);

                   
                }
                else
                {
                        
                        this.SetImageSource(Paused_Out);

                       
                }

            }
        }

  
        #endregion

        /// <summary>
        /// Sets the image source.
        /// </summary>
        /// <param name="imageSource">The lang en image.</param>
        private void SetImageSource(byte[] imageSource)
        {
            try
            {
                using (var ms = new MemoryStream(imageSource, 0, imageSource.Length - 1))
                {
                    var bi = new BitmapImage();

                    bi.BeginInit();
                    bi.StreamSource = ms;
                    bi.CacheOption = BitmapCacheOption.OnLoad;
                    bi.EndInit();
                    
                    this.PartImage.Source = bi;

                    
                }
            }
            catch { }
        }
    }
}
