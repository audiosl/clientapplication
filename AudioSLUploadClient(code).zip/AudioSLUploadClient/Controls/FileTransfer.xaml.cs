﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using AudioSLUploadClient.Classes;
using Microsoft.Win32;
using System.IO;
using AudioSL.Classes;

namespace AudioSLUploadClient.Controls
{
    /// <summary>
    /// Interaction logic for FileTransfer.xaml
    /// </summary>
    public partial class FileTransfer : UserControl
    {

        

        public Uri UploadUrl
        {
            get;
            set;

        }
        public long UploadChunkSize { get; set; }
        public long MaximumUpload { get; set; }
        
        private long TotalOggBytesUploaded { get; set; }
        private long TotalMp3BytesUploaded { get; set; }
        private FileUploadManager fileUpload { get; set; }
     
        AudioConversionManager ac = null;

        //public delegate void FileUploadCompletedDelegate(object sender, FileUploadCompletedEventArgs args);
        //public delegate void FileUploadCancelledDelegate();

        public event FileUploadCompletedDelegate FileUploadCompleted;
        public event FileUploadCancelledDelegate FileUploadCancelled;
    
     //   private bool uploadInvoked;

        public FileTransfer()
        {
            InitializeComponent();

            UploadChunkSize = 40000;
            //  UploadChunkSize = 1048576;
            //  btnAddFile.Click += new RoutedEventHandler(btnAddFile_Click);

            TotalMp3BytesUploaded = 0;
            TotalOggBytesUploaded = 0;
           
            progressBarOgg.Visibility = System.Windows.Visibility.Collapsed;

         //   uploadInvoked = false;
        }

        private void btnAddFile_Click(object sender, RoutedEventArgs e)
        {
             
            OpenFileDialog dlg = new OpenFileDialog();
            dlg.Filter = "WAV Files|*.wav";
            dlg.Multiselect = false;

            if ((bool)dlg.ShowDialog())
            {

                txtFileName.Text = dlg.FileName;

            }
        }

        void fileUploadOgg_FileUploadCompleted(object sender, FileUploadCompletedEventArgs args)
        {

            ac.DeleteFiles();

            if (FileUploadCompleted != null)
            {

                Dispatcher.BeginInvoke(new Action(() =>
                {

                    FileUploadCompleted(sender, args);

                }));

            }

            //fileUpload = new FileUpload(this.Dispatcher, UploadUrl, ac.FileMp3, ac.FileMp3.Name);

            //fileUpload.ContentType = "audio/mp3";
            //fileUpload.UploadProgressChanged += new ProgressChangedEvent(fileUploadMp3_UploadProgressChanged);
            //fileUpload.FileUploadCompleted += new FileUploadCompletedDelegate(fileUploadMp3_FileUploadCompleted);
            //fileUpload.FileUploadCancelled += new FileUploadCancelledDelegate(fileUpload_FileUploadCancelled);

            //if (UploadChunkSize > 0)
            //{
            //    fileUpload.ChunkSize = UploadChunkSize;
            //}

            //Dispatcher.BeginInvoke(new Action(() =>
            //{

            //    progressBarMp3.Maximum = ac.FileMp3.Length;
            //    progressBarMp3.Value = 0;

            //}));

            //fileUpload.UploadChunk();
        }

        void fileUploadMp3_FileUploadCompleted(object sender, FileUploadCompletedEventArgs args)
        {
            ac.DeleteFiles();

            if (FileUploadCompleted != null)
            {

                Dispatcher.BeginInvoke(new Action(() =>
                {

                    FileUploadCompleted(sender, args);
                    
                }));

            }
        }

        void fileUpload_FileUploadCancelled()
        {

            ac.DeleteFiles();

            //if (FileUploadCancelled != null)
            //{
            //    FileUploadCancelled();
            //}

            txtFileName.Text = String.Empty;

            Dispatcher.BeginInvoke(new Action(() =>
            {

                progressBarOgg.Visibility = System.Windows.Visibility.Collapsed;
            


            }));

            if (FileUploadCancelled != null)
            {
                
                Dispatcher.BeginInvoke(new Action(() =>
                {

                    FileUploadCancelled();


                }));

            }

            fileUpload = null;
            

        }

        void fileUploadOgg_UploadProgressChanged(object sender, Classes.UploadProgressChangedEventArgs args)
        {
            progressBarOgg.Visibility = System.Windows.Visibility.Visible;

            TotalOggBytesUploaded += args.BytesUploaded;
            progressBarOgg.Value = TotalOggBytesUploaded;

        }

        void fileUploadMp3_UploadProgressChanged(object sender, Classes.UploadProgressChangedEventArgs args)
        {
        
            TotalMp3BytesUploaded += args.BytesUploaded;
         

        }

        public void Upload()
        {

            try
            {
                //upload has to be called on all file upload objects before the form can post
             //   uploadInvoked = true;
                btnAddFile.IsEnabled = false;

                ac = new AudioSL.Classes.AudioConversionManager(txtFileName.Text, Globals.SessionKey, Globals.BinariesFolder, Globals.AudioRepositoryFolder, Globals.OrganizationID);

                fileUpload = new FileUploadManager(this.Dispatcher, UploadUrl, ac.FileOgg, ac.FileOgg.Name);
                fileUpload.Status = FileUploadStatus.Pending;
                fileUpload.ContentType = "audio/ogg";

                fileUpload.UploadProgressChanged += new ProgressChangedEvent(fileUploadOgg_UploadProgressChanged);
                fileUpload.FileUploadCompleted += new FileUploadCompletedDelegate(fileUploadOgg_FileUploadCompleted);
                fileUpload.FileUploadCancelled += new FileUploadCancelledDelegate(fileUpload_FileUploadCancelled);

                if (UploadChunkSize > 0)
                {
                    fileUpload.ChunkSize = UploadChunkSize;
                }

                Dispatcher.BeginInvoke(new Action(() =>
                {
                    progressBarOgg.Maximum = ac.FileOgg.Length;
                    progressBarOgg.Value = 0;


                }));


                fileUpload.UploadChunk();
            }
            catch (Exception ex)
            {
                AudioSL.Globals.LogError(ex);
                MessageBox.Show("An error has been generated.");
            }
        }

    }
}
